package ua.lviv.lgs;


import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;


public class Main 
{
	private static Logger LOG = Logger.getLogger(Main.class);
    public static void main( String[] args )
    {
    	
    		logWithDomConfigurator();
    		
    		String[] arr = {"1","2","3","4"};
    		
    		try {
    			
    			arr[100] = "fff";
				
			} catch (ArrayIndexOutOfBoundsException e) {
				LOG.error(e);
				LOG.warn(e);
			} finally {
				LOG.info("error tests");
			}
    		
    }
    	

    	public static void logWithDomConfigurator() {
    		DOMConfigurator.configure("log4j.xml");	
    		LOG.trace("TRACE Logger mesaage of project");
    		LOG.debug("DEBUG Logger mesaage of project");
    		LOG.info("INFO Logger mesaage of project");
    		LOG.warn("WARN Logger mesaage of project");
    		LOG.error("ERROR Logger mesaage of project");
    		LOG.fatal("FATAL Logger mesaage of project");
    	}
}
