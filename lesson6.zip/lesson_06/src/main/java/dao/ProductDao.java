package dao;

import domain.Product;
import shared.AbstractCRUD;

public interface ProductDao extends AbstractCRUD<Product>{

}
