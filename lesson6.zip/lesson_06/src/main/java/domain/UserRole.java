package domain;

public enum UserRole {
	ADMINISTRATOR, USER;
}
