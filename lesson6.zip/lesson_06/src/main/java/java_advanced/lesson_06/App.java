package java_advanced.lesson_06;

public class App {

	public static void main(String[] args) {
		

	}
}
