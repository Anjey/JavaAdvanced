package service;

import domain.Bucket;
import shared.AbstractCRUD;

public interface BucketService extends AbstractCRUD<Bucket>{

}
