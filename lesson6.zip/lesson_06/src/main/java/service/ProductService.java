package service;

import domain.Product;
import shared.AbstractCRUD;

public interface ProductService extends AbstractCRUD<Product>{

}
