package service;

import dao.UserDao;

public interface UserService extends UserDao{

}
