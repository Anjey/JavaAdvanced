package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.User;
import service.UserService;
import service.impl.UserServiceImpl;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = -154176561953216931L;
	private UserService userService = UserServiceImpl.getUserService();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String login = req.getParameter("login");
		String password = req.getParameter("password");
		
		User user = userService.getUserByEmail(login);

		if (user == null) {
			// TODO: User does not exists!
			req.getRequestDispatcher("login.jsp").forward(req, resp);
			return;
		}

		if (!user.getPassword().equals(password)) {
			// TODO: User password wrong!
			req.getRequestDispatcher("login.jsp").forward(req, resp);
			return;
		}

		req.setAttribute("userEmail", login);
		req.getRequestDispatcher("cabinet.jsp").forward(req, resp);
	}

}
