package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.User;
import domain.UserRole;
import service.UserService;
import service.impl.UserServiceImpl;

@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {

	private static final long serialVersionUID = -2095222788167013383L;
	private UserService userService = UserServiceImpl.getUserService();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String email = req.getParameter("email");
		String firstName = req.getParameter("firstName");
		String lastName = req.getParameter("lastName");
		String password = req.getParameter("password");

		if (email.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || password.isEmpty()) {
			// TODO: Some field is empty!
		} else {
			User user = new User(email, firstName, lastName, UserRole.USER.toString(), password);
			userService.create(user);
		}
		
		req.setAttribute("userEmail", email);
		req.getRequestDispatcher("cabinet.jsp").forward(req, resp);
	}

}
