package dto;

public class UserLogin {
	public String userEmail;
	public String destinationUrl;
}
